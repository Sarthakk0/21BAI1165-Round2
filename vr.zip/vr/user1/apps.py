from django.apps import AppConfig


class User1Config(AppConfig):
    name = 'user1'
