from django.shortcuts import render
from user1.models import user
# Create your views here.
def index(request):
    obj = user.objects.get(id = 1)
    x = int(obj.number)+1
    print(x)
    obj.number = f"{x}"
    obj.save()
    
    return render(request,"index.html",{'obj':obj})

def product(request):

    return render(request,"product.html")